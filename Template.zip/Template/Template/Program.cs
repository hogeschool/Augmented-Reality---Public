﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using ImageUtilities;

namespace Template
{
  public class Program
  {
    static Color[,] Grid(Color[,] image, int spacing)
    {
      Color[,] grid = new Color[image.GetLength(0), image.GetLength(1)];
      for (int i = 0; i < image.GetLength(0); i++)
      {
        for (int j = 0; j < image.GetLength(1); j++)
        {
          if (i % spacing == 0 || j % spacing == 0)
          {
            grid[i, j] = Color.Black;
          }
          else
          {
            grid[i, j] = image[i, j];
          }
        }
      }
      return grid;
    }

    static void Main(string[] args)
    {
      Color[,] image1 = ImageViewer.LoadImage(@"Content\terminator_marine.jpg");
      Color[,] grid = Grid(image1, 20);
      ImageViewer.DrawImagePair(image1, grid);
    }
  }
}
